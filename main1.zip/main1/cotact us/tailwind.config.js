/**@type {import ('tailwindcss').config} */
module.exports = {
    fontFamily:{
        yekan:['Yekan'],
    }
}