function toggleSidebar() {
    let sidebar = document.getElementById("sidebar");
    let main = document.getElementById("main");
    let openBtn=document.getElementById("openBtn")
    if (sidebar.style.right === "-250px") {
        sidebar.style.right = "0";        
    } else {
        sidebar.style.right = "-250px";
    }
}
document.getElementById("addTask").addEventListener("click", function() {
    document.getElementById("popUpForm").classList.remove("hidden");
});

document.getElementById("closeFormBtn").addEventListener("click", function() {
    document.getElementById("popUpForm").classList.add("hidden");
});
// option
document.getElementById("addOption").addEventListener("click", function() {
    document.getElementById("popUpOption").classList.remove("hidden");
});

document.getElementById("closeOption").addEventListener("click", function() {
    document.getElementById("popUpOption").classList.add("hidden");
});
// Edit
document.getElementById("addEdit").addEventListener("click", function() {
    document.getElementById("popUpEdit").classList.remove("hidden");
    document.getElementById("popUpOption").classList.add("hidden");
});

document.getElementById("closeEdit").addEventListener("click", function() {
    document.getElementById("popUpEdit").classList.add("hidden");
});